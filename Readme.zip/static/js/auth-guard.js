/**
 * auth-guard.js
 * Include vào đầu mỗi trang protected.
 * - Nếu không có token → redirect login
 * - Expose getToken() và authHeaders() cho toàn trang
 * - Tự động refresh hoặc logout khi token hết hạn (401)
 * - Staff chỉ được truy cập /me, không được vào /dashboard /report /users
 */

(function () {
  const LOGIN_PAGE = '/auth/login-page';
  const MANAGER_ONLY = ['/dashboard', '/shifts', '/report', '/users', '/integrations'];

  function getToken() {
    return localStorage.getItem('access_token') || sessionStorage.getItem('access_token') || '';
  }

  function getRefreshToken() {
    return localStorage.getItem('refresh_token') || sessionStorage.getItem('refresh_token') || '';
  }

  function getAuthStorage() {
    return localStorage.getItem('refresh_token') ? localStorage : sessionStorage;
  }

  function getUser() {
    try { return JSON.parse(localStorage.getItem('user') || sessionStorage.getItem('user') || 'null'); } catch { return null; }
  }

  function getJwtPayload(token) {
    try {
      const payload = token.split('.')[1];
      const normalized = payload.replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(payload.length / 4) * 4, '=');
      return JSON.parse(atob(normalized));
    } catch {
      return null;
    }
  }

  function isAccessExpired(token, skewSeconds) {
    const payload = getJwtPayload(token);
    if (!payload || !payload.exp) return true;
    return payload.exp * 1000 <= Date.now() + (skewSeconds || 0) * 1000;
  }

  function clearAuth() {
    ['access_token','refresh_token','user'].forEach(k => {
      localStorage.removeItem(k); sessionStorage.removeItem(k);
    });
  }

  function redirectLogin() {
    clearAuth();
    window.location.href = LOGIN_PAGE + '?next=' + encodeURIComponent(window.location.pathname);
  }

  // Kiểm tra role — staff không được vào trang quản lý
  const user = getUser();
  const currentPath = window.location.pathname;
  if (user && user.role === 'staff' && MANAGER_ONLY.some(p => currentPath.startsWith(p))) {
    window.location.href = '/me';
    throw new Error('Redirecting staff to /me');
  }

  // Expose ra global
  window.getToken = getToken;
  window.getUser  = getUser;

  let refreshPromise = null;

  async function refreshAuth() {
    const rt = getRefreshToken();
    if (!rt) return false;

    if (!refreshPromise) {
      refreshPromise = fetch('/auth/refresh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: rt })
      })
        .then(async function (res) {
          if (!res.ok) return false;
          const data = await res.json();
          if (!data.access_token || !data.refresh_token) return false;
          const storage = getAuthStorage();
          storage.setItem('access_token', data.access_token);
          storage.setItem('refresh_token', data.refresh_token);
          return true;
        })
        .catch(function () { return false; })
        .finally(function () { refreshPromise = null; });
    }

    return refreshPromise;
  }

  async function ensureFreshAccess() {
    const token = getToken();
    if (token && !isAccessExpired(token, 30)) return true;
    return refreshAuth();
  }

  // Kiểm tra ngay khi trang load. Nếu chỉ còn refresh token thì giữ trang lại
  // để authFetch có cơ hội lấy access token mới.
  if (!getToken() && !getRefreshToken()) {
    redirectLogin();
    throw new Error('Redirecting to login');
  }

  window.authHeaders = function (extra) {
    return Object.assign({ 'Authorization': 'Bearer ' + getToken() }, extra || {});
  };

  // Wrapper fetch tự động refresh access token khi gần hết hạn rồi retry 1 lần nếu vẫn gặp 401
  window.authFetch = async function (url, options) {
    options = options || {};
    const fresh = await ensureFreshAccess();
    if (!fresh) {
      redirectLogin();
      throw new Error('Unauthorized');
    }
    options.headers = Object.assign(
      { 'Authorization': 'Bearer ' + getToken() },
      options.headers || {}
    );

    let res = await fetch(url, options);
    if (res.status === 401) {
      const refreshed = await refreshAuth();
      if (refreshed) {
        options.headers = Object.assign({}, options.headers, {
          'Authorization': 'Bearer ' + getToken()
        });
        res = await fetch(url, options);
      }
    }

    if (res.status === 401 || res.status === 403) {
      redirectLogin();
      throw new Error('Unauthorized');
    }
    return res;
  };

  window.updateLeaveNavBadge = function (count) {
    const n = Number(count) || 0;
    document.querySelectorAll('a.nav-link[href="/dashboard?tab=leave"]').forEach(function (link) {
      let badge = link.querySelector('.nav-alert-badge');
      if (!badge) {
        badge = document.createElement('span');
        badge.className = 'nav-alert-badge';
        link.appendChild(badge);
      }
      badge.textContent = n > 99 ? '99+' : String(n);
      badge.classList.toggle('show', n > 0);
      link.setAttribute('aria-label', n > 0 ? 'Nghỉ phép, có ' + n + ' đơn chờ duyệt' : 'Nghỉ phép');
    });
  };

  async function refreshLeaveNavBadge() {
    if (!user || (user.role !== 'admin' && user.role !== 'manager')) return;
    if (!document.querySelector('a.nav-link[href="/dashboard?tab=leave"]')) return;
    try {
      const res = await window.authFetch('/api/leave/pending-count');
      const data = await res.json();
      window.updateLeaveNavBadge(data.count || 0);
    } catch {}
  }

  // Nút logout nếu có + hiện tên user
  document.addEventListener('DOMContentLoaded', function () {
    if (document.getElementById('mainNav')) {
      document.body.classList.add('admin-shell');
    }

    const sidebarHeader = document.querySelector('body.admin-shell header');
    if (sidebarHeader && !document.querySelector('[data-sidebar-toggle]')) {
      const toggle = document.createElement('button');
      toggle.type = 'button';
      toggle.className = 'sidebar-collapse-btn';
      toggle.setAttribute('data-sidebar-toggle', '');
      toggle.setAttribute('aria-label', 'Thu gọn thanh điều hướng');
      toggle.innerHTML = '<span aria-hidden="true">‹</span>';
      sidebarHeader.appendChild(toggle);

      const applySidebarState = function (collapsed) {
        document.body.classList.toggle('nav-collapsed', collapsed);
        toggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
        toggle.setAttribute('aria-label', collapsed ? 'Mở rộng thanh điều hướng' : 'Thu gọn thanh điều hướng');
      };

      applySidebarState(localStorage.getItem('sidebar_collapsed') === '1');
      toggle.addEventListener('click', function () {
        const collapsed = !document.body.classList.contains('nav-collapsed');
        localStorage.setItem('sidebar_collapsed', collapsed ? '1' : '0');
        applySidebarState(collapsed);
      });
    }

    // Hiện tên user ở nav nếu có element #navUserName
    const nameEl = document.getElementById('navUserName');
    if (nameEl && user) {
      nameEl.textContent = user.full_name || user.email || '';
    }

    // Ẩn link Tài khoản nếu role không phải admin
    const navUsers = document.getElementById('navUsers');
    if (navUsers && user && user.role !== 'admin') {
      navUsers.style.display = 'none';
    }
    const navIntegrations = document.getElementById('navIntegrations');
    if (navIntegrations && user && user.role !== 'admin') {
      navIntegrations.style.display = 'none';
    }
    const navSystemTitle = document.getElementById('navSystemTitle');
    if (navSystemTitle && user && user.role !== 'admin') {
      navSystemTitle.style.display = 'none';
    }
    refreshLeaveNavBadge();

    document.querySelectorAll('[data-logout]').forEach(function (el) {
      el.addEventListener('click', function () {
        const rt = localStorage.getItem('refresh_token') || sessionStorage.getItem('refresh_token');
        if (rt) {
          fetch('/auth/logout', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ refresh_token: rt })
          }).finally(function () { redirectLogin(); });
        } else {
          redirectLogin();
        }
      });
    });
  });
})();
